% a��7=0+3+4
% b��5=0+2+3
% c��4=0+3+1��round��

clear;
close all;
clc;

cntwhole = 1;
for a = 0:2^-4:8-2^-4
	for b = 0:2^-3:4-2^-3
		a2 = floor(a * 2^4);
		b2 = floor(b * 2^3);
		
		c = plus_float(a2,b2);
		c = c/2;
		c_real = a + b;
		if c_real > 8 - 2^-1
			c_real = 8 - 2^-1;
		end
		
		err = abs(c_real - c);
		a_group(cntwhole) = a;
		b_group(cntwhole) = b;
		c_group(cntwhole) = c;
		c_real_group(cntwhole) = c_real;
		err_group(cntwhole) = err;
		cntwhole = cntwhole + 1;
	end
end

figure;plot(err_group);grid on;

