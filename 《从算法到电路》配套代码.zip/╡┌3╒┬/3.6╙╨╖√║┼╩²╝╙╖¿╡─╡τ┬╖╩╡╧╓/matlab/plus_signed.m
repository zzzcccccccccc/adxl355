% a: 8=1+3+4
% b: 6=1+2+3
% c: 5=1+3+1(round)

function c = plus_signed(a,b)

b2 = b * 2;

% c2: 9=1+4+4
c2 = a + b2;

% c3: 8=1+5+2
c3 = floor(c2/2^2) + 1;

% c4: 7=1+5+1
c4 = floor(c3/2);

% c�������
if c4 > 2^4 - 1
	c = 2^4 - 1;
elseif c4 < -2^4
	c = -2^4; 
else
	c = c4;
end











