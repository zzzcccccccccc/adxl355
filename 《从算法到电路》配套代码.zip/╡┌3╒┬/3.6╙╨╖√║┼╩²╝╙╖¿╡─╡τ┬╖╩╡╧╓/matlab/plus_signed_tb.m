clear;
close all;
clc;

cntwhole = 1;
for cnt1 = -8:2^-4:8-2^-4
	for cnt2 = -4:2^-3:4-2^-3
		a = round(cnt1*2^4);
		b = round(cnt2*2^3);
		c = plus_signed(a,b);
		c = c/2;
		
		c_real = cnt1 + cnt2;
		if c_real > 7.5
			c_real = 7.5;
		elseif c_real <= -8
			c_real = -8;	
		end
		
		err = abs(c_real - c);
		a_group(cntwhole) = a;
		b_group(cntwhole) = b;
		c_group(cntwhole) = c;
		c_real_group(cntwhole) = c_real;
		err_group(cntwhole) = err;
		cntwhole = cntwhole + 1;
	end
end

figure;plot(err_group);grid on;







