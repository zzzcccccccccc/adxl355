clc;
clear;
close all;

a_reg   = zeros(1,1048576);
b_reg   = zeros(1,1048576);
c_reg   = zeros(1,1048576);
err_reg = zeros(1,1048576);

cntwhole = 1;
num_range = 0:2^10-1;

for cnt1 = num_range
	a = cnt1;
	
	for cnt2 = num_range
		b = cnt2;
% 		c = cordic_multi_float(a,b);
% 		c = cordic_multi_fix(a,b);
		c = cordic_multi_fix_max(a,b);
% 		c = cordic_multi_fix2(a,b);
		c_real = a * b;
		
		err = abs(c_real - c);
		
		a_reg(cntwhole) = a;
		b_reg(cntwhole) = b;
		err_reg(cntwhole) = err;
		cntwhole = cntwhole + 1;
	end
end

figure;plot(err_reg);grid on;


















