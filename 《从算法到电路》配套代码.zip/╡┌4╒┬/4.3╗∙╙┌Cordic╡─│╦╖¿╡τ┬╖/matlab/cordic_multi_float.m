function c = cordic_multi_float(a, b)
if b >= 512
	b_shift_bit = 9;
elseif b >= 256
	b_shift_bit = 8;
elseif b >= 128
	b_shift_bit = 7;
elseif b >= 64
	b_shift_bit = 6;	
elseif b >= 32
	b_shift_bit = 5;
elseif b >= 16
	b_shift_bit = 4;
elseif b >= 8
	b_shift_bit = 3;
elseif b >= 4
	b_shift_bit = 2;
elseif b >= 2
	b_shift_bit = 1;
else
	b_shift_bit = 0;
end

b2 = b/2^b_shift_bit;

c   = 0;
itr = 20;
for cnt = 0:itr-1
	tmp = 2^(-cnt);
	
	if b2 >= 0
		c  = c + 2^(-cnt) * a; 
		b2 = b2 - tmp;
	else
		c  = c - 2^(-cnt) * a; 
		b2 = b2 + tmp;
	end
end

c = floor(c * 2^b_shift_bit);

