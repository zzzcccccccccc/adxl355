function [absa, a2] = abs_float(x, y)

x2 = abs(x);
y2 = abs(y);

itr = 15;
a   = 0;

for cnt = 0:itr-1
	tt   = atan(2^(-cnt));
	tmp1 = 2^(-cnt)*y2;
	tmp2 = 2^(-cnt)*x2;
	
	if y2 >= 0
		x2 = x2 + tmp1;
		y2 = y2 - tmp2;
		a  = a  + tt;
	else
		x2 = x2 - tmp1;
		y2 = y2 + tmp2;
		a  = a  - tt;
	end
end

absa = 0.607252935008881 * x2;

if (x > 0 && y < 0)
	a2 = 2*pi-a;
elseif (x == 0 && y == 0)
	a2 = 0;
elseif (x < 0 && y >= 0)
	a2 = pi-a;
elseif (x <= 0 && y < 0)
	a2 = pi+a;
else
	a2 = a;
end







