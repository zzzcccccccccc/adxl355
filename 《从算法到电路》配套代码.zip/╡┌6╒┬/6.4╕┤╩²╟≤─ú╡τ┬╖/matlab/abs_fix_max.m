% x:9=1+3+5
% y:9=1+3+5
% absa: 9=0+4+5
% a: 10=0+10+0

function [absa, a3] = abs_fix_max(x,y)

%x2:9=0+4+5
x2 = abs(x);

%y2:9=0+4+5
y2 = abs(y);

itr = 19;
a   = 0;

exp_x  = 14;
exp_a  = 14;

x3 = floor(x2 * 2^exp_x);

cfg_x3_wid = 24;
if x3 >= 2^cfg_x3_wid
	x3 = mod(x3,2^cfg_x3_wid);
elseif x3 >= 0
	x3 = x3;
else
	fprintf('x3 < 0: %d\n',x3);
end

y3 = floor(y2 * 2^exp_x);

cfg_y3_wid = 24;
if (y3 >= 2^(cfg_y3_wid-1)) || (y3 < -2^(cfg_y3_wid-1))
	y3 = y3-(floor((y3-2^(cfg_y3_wid-1))/2^cfg_y3_wid)+1)*2^cfg_y3_wid;
else
	y3 = y3;
end


for cnt = 0:itr-1
	tt   = round(atan(2^(-cnt))/(2*pi/1024) * 2^exp_a);
	
	cfg_tt_wid = 22;
	if tt >= 2^cfg_tt_wid
		tt = mod(tt,2^cfg_tt_wid);
	elseif tt >= 0
		tt = tt;
	else
		fprintf('tt < 0: %d\n',tt);
	end
	
	tmp1 = floor(2^(-cnt) * y3);
	
	cfg_tmp1_wid = 24;
	if (tmp1 >= 2^(cfg_tmp1_wid-1)) || (tmp1 < -2^(cfg_tmp1_wid-1))
		tmp1 = tmp1-(floor((tmp1-2^(cfg_tmp1_wid-1))/2^cfg_tmp1_wid)+1)*2^cfg_tmp1_wid;
	else
		tmp1 = tmp1;
	end
	
	tmp2 = floor(2^(-cnt) * x3);
	
	cfg_tmp2_wid = 23;
	if tmp2 >= 2^cfg_tmp2_wid
		tmp2 = mod(tmp2,2^cfg_tmp2_wid);
	elseif tmp2 >= 0
		tmp2 = tmp2;
	else
		fprintf('tmp2 < 0: %d\n',tmp2);
	end
	
	if y3 >= 0
		x3 = x3 + tmp1;
		y3 = y3 - tmp2;
		a  = a  + tt;
	else
		x3 = x3 - tmp1;
		y3 = y3 + tmp2;
		a  = a  - tt;
	end
	
	if x3 >= 2^cfg_x3_wid
		x3 = mod(x3,2^cfg_x3_wid);
	elseif x3 >= 0
		x3 = x3;
	else
		fprintf('x3 < 0: %d\n',x3);
	end
	
	if (y3 >= 2^(cfg_y3_wid-1)) || (y3 < -2^(cfg_y3_wid-1))
		y3 = y3-(floor((y3-2^(cfg_y3_wid-1))/2^cfg_y3_wid)+1)*2^cfg_y3_wid;
	else
		y3 = y3;
	end
	
	cfg_a_wid = 24;
	if (a >= 2^(cfg_a_wid-1)) || (a < -2^(cfg_a_wid-1))
		a = a-(floor((a-2^(cfg_a_wid-1))/2^cfg_a_wid)+1)*2^cfg_a_wid;
	else
		a = a;
	end
end

exp_coeff = 19;
x4 = round(x3/2^(exp_x-9));

cfg_x4_wid = 19;
if x4 >= 2^cfg_x4_wid
	x4 = mod(x4,2^cfg_x4_wid);
elseif x4 >= 0
	x4 = x4;
else
	fprintf('x4 < 0: %d\n',x4);
end

absa = round(round(0.607252935008881*2^exp_coeff) * x4/2^(exp_coeff+9));

a2 = round(a/2^exp_a);

cfg_a2_wid = 9;
if a2 >= 2^cfg_a2_wid
	a2 = mod(a2,2^cfg_a2_wid);
elseif a2 >= 0
	a2 = a2;
else
	fprintf('a2 < 0: %d\n',a2);
end

if (x > 0 && y < 0)
	a3 = 1024-a2;
elseif (x == 0 && y == 0)
	a3 = 0;
elseif (x < 0 && y >= 0)
	a3 = 512-a2;
elseif (x <= 0 && y < 0)
	a3 = 512+a2;
else
	a3 = a2;
end

cfg_a3_wid = 10;
if a3 >= 2^cfg_a3_wid
	a3 = mod(a2,2^cfg_a3_wid);
elseif a3 >= 0
	a3 = a3;
else
	fprintf('a3 < 0: %d\n',a3);
end



