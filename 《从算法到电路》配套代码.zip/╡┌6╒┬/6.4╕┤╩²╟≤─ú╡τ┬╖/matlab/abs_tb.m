% x:    9=1+3+5
% y:    9=1+3+5
% absa: 9=0+4+5
% a:    10=0+10+0

close all;
clc;
clear;

deltx  = 2^-5;
delt_a = 2*pi/1024;

cnt = 1;
v = -8:deltx:8-deltx;

for cnt1 = 1:512
	for cnt2 = 1:512
		x = v(cnt1);
		y = v(cnt2);
		
		x_fix = round(x/deltx);
		y_fix = round(y/deltx);
		
		absa_real = abs(x+1i*y);
		a_real    = mod(angle(x+1i*y), 2*pi);
		
% 		[absa, a] = abs_float(x,y);
% 		[absa_fix, a_fix] = abs_fix(x_fix, y_fix); absa = absa_fix*deltx;a = a_fix*delt_a;
% 		[absa_fix, a_fix] = abs_fix_max(x_fix, y_fix); absa = absa_fix*deltx;a = a_fix*delt_a;
		[absa_fix, a_fix] = abs_fix2(x_fix, y_fix);absa = absa_fix*deltx;a = a_fix*delt_a;	

		err_abs(cnt) = abs(absa_real - absa);
		err_a(cnt)   = abs(a_real    - a);

		cnt = cnt + 1;
	end
end

figure(1);plot(err_abs);grid on;
figure(2);plot(err_a);grid on;

max(abs(err_abs))
max(abs(err_a))


















