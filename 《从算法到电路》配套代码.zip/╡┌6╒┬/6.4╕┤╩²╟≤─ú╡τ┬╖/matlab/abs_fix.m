% x:9=1+3+5
% y:9=1+3+5
% absa: 9=0+4+5
% a: 10=0+10+0

function [absa, a3] = abs_fix(x,y)

%x2:9=0+4+5
x2 = abs(x);

%y2:9=0+4+5
y2 = abs(y);

itr = 19;
a   = 0;

exp_x  = 14;
exp_a  = 14;

x3 = floor(x2 * 2^exp_x);
y3 = floor(y2 * 2^exp_x);

for cnt = 0:itr-1
	tt   = round(atan(2^(-cnt))/(2*pi/1024) * 2^exp_a);
	tmp1 = floor(2^(-cnt) * y3);
	tmp2 = floor(2^(-cnt) * x3);
	
	if y3 >= 0
		x3 = x3 + tmp1;
		y3 = y3 - tmp2;
		a  = a  + tt;
	else
		x3 = x3 - tmp1;
		y3 = y3 + tmp2;
		a  = a  - tt;
	end
end

exp_coeff = 19;
x4 = round(x3/2^(exp_x-9));
absa = round(round(0.607252935008881*2^exp_coeff) * x4/2^(exp_coeff+9));

a2 = round(a/2^exp_a);

if (x > 0 && y < 0)
	a3 = 1024-a2;
elseif (x == 0 && y == 0)
	a3 = 0;
elseif (x < 0 && y >= 0)
	a3 = 512-a2;
elseif (x <= 0 && y < 0)
	a3 = 512+a2;
else
	a3 = a2;
end



