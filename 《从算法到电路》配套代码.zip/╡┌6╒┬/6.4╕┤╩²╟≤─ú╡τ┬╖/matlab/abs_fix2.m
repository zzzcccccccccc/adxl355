% x:9=1+3+5
% y:9=1+3+5
% absa: 9=0+4+5
% a: 10=0+10+0

function [absa, a3] = abs_fix2(x,y)

%x2:9=0+4+5
x2 = abs(x);

%y2:9=0+4+5
y2 = abs(y);

%a:24=1+9+14
a   = 0;

%x3:24=0+5+19
x3 = floor(x2 * 2^14);

%y3:24=1+4+19
y3 = floor(y2 * 2^14);

%tt:22=0+8+14
tt = [2097152,1238021,654136,332050,166669,83416,41718,20860,10430,5215,2608,1304,652,326,163,81,41,20,10];

for cnt = 0:18
	%tmp1:24=1+4+19
	tmp1 = floor(2^(-cnt) * y3);
	
	%tmp2:23=0+4+19
	tmp2 = floor(2^(-cnt) * x3);
	
	if y3 >= 0
		x3 = x3 + tmp1;
		y3 = y3 - tmp2;
		a  = a  + tt(cnt+1);
	else
		x3 = x3 - tmp1;
		y3 = y3 + tmp2;
		a  = a  - tt(cnt+1);
	end
end

%x4:19=0+5+14
x4   = round(x3/2^5);

%absa:9=0+4+5
absa = round(318375 * x4/2^28);

%a2:9=0+9+0
a2   = round(a/2^14);

%a3:10=0+10+0
if (x > 0 && y < 0)
	a3 = 1024-a2;
elseif (x == 0 && y == 0)
	a3 = 0;
elseif (x < 0 && y >= 0)
	a3 = 512-a2;
elseif (x <= 0 && y < 0)
	a3 = 512+a2;
else
	a3 = a2;
end



