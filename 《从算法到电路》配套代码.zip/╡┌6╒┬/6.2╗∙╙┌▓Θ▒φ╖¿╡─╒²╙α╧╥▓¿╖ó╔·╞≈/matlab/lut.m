clc;
clear;
close all;


%% ����һ���Ƕȵ�cos
delt_a = 2*pi/2^10;
a = [0:delt_a:2*pi-delt_a];
cosa_real = cos(a);
sina_real = sin(a);


%% ----------------------
cosa_real_wr = round(cosa_real * 2^11);
sina_real_wr = round(sina_real * 2^11);

idx = find(cosa_real_wr < 0);
cosa_real_wr(idx) = 2^13 + cosa_real_wr(idx);

idx = find(sina_real_wr < 0);
sina_real_wr(idx) = 2^13 + sina_real_wr(idx);

fp = fopen('rtl_code.txt','w');
group_num = -1;
for cnt = 0:1023
	cnt_tmp = mod(cnt,32);
	
	if cnt_tmp == 0
		group_num = group_num + 1;
		fprintf(fp,'always @(posedge clk or negedge rstn)\n');
		fprintf(fp,'begin\n');
		fprintf(fp,'\tif(!rstn)\n');
		fprintf(fp,'\tbegin\n');
		fprintf(fp,'\t\tcosa_%d <= {1''b0, 1''b1, 11''d0};\n',group_num);
		fprintf(fp,'\t\tsina_%d <= 13''d0;\n',group_num);
		fprintf(fp,'\tend\n');
		fprintf(fp,'\telse if (clk_vld & trig)\n');
		fprintf(fp,'\tbegin\n');
		fprintf(fp,'\t\tcase(a[4:0])\n');
	end
	
	fprintf(fp,'\t\t\t5''d%d:\n',cnt_tmp);
	fprintf(fp,'\t\t\tbegin\n');
	fprintf(fp,'\t\t\t\tcosa_%d <= 13''h%x;\n', group_num, cosa_real_wr(cnt+1));
	fprintf(fp,'\t\t\t\tsina_%d <= 13''h%x;\n', group_num, sina_real_wr(cnt+1));
	fprintf(fp,'\t\t\tend\n');
	fprintf(fp,'\n');
	
	if cnt_tmp == 31
		fprintf(fp,'\t\tendcase\n');
		fprintf(fp,'\tend\n');
		fprintf(fp,'end\n');
		fprintf(fp,'\n\n\n');
	end
end

fprintf(fp,'always @(posedge clk or negedge rstn)\n');
fprintf(fp,'begin\n');
fprintf(fp,'\tif(!rstn)\n');
fprintf(fp,'\tbegin\n');
fprintf(fp,'\t\tcosa3_latch <= {1''b0, 1''b1, 11''d0};\n');
fprintf(fp,'\t\tsina3_latch <= 13''d0;\n');
fprintf(fp,'\tend\n');
fprintf(fp,'\telse if (clk_vld & trig_r)\n');
fprintf(fp,'\tbegin\n');
fprintf(fp,'\t\tcase(a[9:5])\n');

for cnt = 0:31
	fprintf(fp,'\t\t\t5''d%d:\n',cnt);
	fprintf(fp,'\t\t\tbegin\n');
	fprintf(fp,'\t\t\t\tcosa3_latch <= cosa_%d;\n',cnt);
	fprintf(fp,'\t\t\t\tsina3_latch <= sina_%d;\n',cnt);
	fprintf(fp,'\t\t\tend\n');
end

fprintf(fp,'\t\tendcase\n');
fprintf(fp,'\tend\n');
fprintf(fp,'end\n');


fclose(fp);






















