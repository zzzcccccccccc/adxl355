clear;
clc;
close all;

delt_a = 2^-4;
delt_b = 2^-2;
delt_c = 2^-7;
cntwhole = 1;
err_whole = 0;
for a = -32:delt_a:32-delt_a
	for b = -8:delt_b:8-delt_b
		a_fix = a/delt_a;
		b_fix = b/delt_b;
		
% 		c = linear_div_float(a, b);
% 		c = linear_div_fix(a_fix, b_fix)/2^7;
		c = linear_div_fix_max(a_fix, b_fix)/2^7;
% 		c = linear_div_fix2(a_fix, b_fix)/2^7;
	
		c_real = a/b;
		if c_real >= 256
			c_real = 256 - delt_c;
		elseif c_real < -256
			c_real = -256;
		end
		
		err = abs(c_real - c);
		
		if err_whole < err
			err_whole = err;
		end
		
		err_reg(cntwhole) = err;
		cntwhole = cntwhole + 1;
	end
end
figure;plot(err_reg);grid on;

if err_whole > 2^-7
	bai = 1
else
	bai = 0
end

