%a: 10=1+5+4
%b: 6=1+3+2
%c3: 16=1+8+7
function c3 = cordic_div_fix_max(a, b)

%��ȡ����
if ((a >= 0) && (b >= 0)) || ((a < 0) && (b < 0))
	sign_flag = 0;
else
	sign_flag = 1;
end

%10=0+6+4
if a >= 0
	a2 = a;
else
	a2 = -a;
end

%5=0+3+2
if b >= 0
	b2 = b;
else
	b2 = -b;
end

%���̿�����С��2��Χ��
%��֪���ӵ����λ
if a ~= 0
	bai_a = floor(log2(a2));
else
	bai_a = 0;
end

if b ~= 0
	bai_b = floor(log2(b2));
else
	bai_b = 0;
end

%----------------------------------------
%4=1+3+0
a_shift_bit = bai_a - bai_b - 2;

cfg_a_shift_bit_wid = 4;
if (a_shift_bit >= 2^(cfg_a_shift_bit_wid-1)) || (a_shift_bit < -2^(cfg_a_shift_bit_wid-1))
	a_shift_bit = a_shift_bit-(floor((a_shift_bit-2^(cfg_a_shift_bit_wid-1))/2^cfg_a_shift_bit_wid)+1)*2^cfg_a_shift_bit_wid;
else
	a_shift_bit = a_shift_bit;
end

%----------------------------------------
a3_point = 10;
a3 = floor(a2 * 2^-a_shift_bit * 2^-4 * 2^a3_point);	%0+3+a3_point

cfg_a3_wid = 13;
if a3 >= 2^cfg_a3_wid
	a3 = mod(a3,2^cfg_a3_wid);
elseif a3 >= 0
	a3 = a3;
else
	fprintf('a3 < 0: %d\n',a3);
end

%----------------------------------------
a4_point = 13;
if a3 < b2*2^(a3_point-2)
	a4 = floor(a3 * 2 *2^-a3_point * 2^a4_point);	%1+4+a4_point
	a_shift_bit = a_shift_bit - 1;			%4=1+3+0
else
	a4 = floor(a3 * 2^-a3_point * 2^a4_point);
	a_shift_bit = a_shift_bit;
end

cfg_a4_wid = 18;
if (a4 >= 2^(cfg_a4_wid-1)) || (a4 < -2^(cfg_a4_wid-1))
	a4 = a4-(floor((a4-2^(cfg_a4_wid-1))/2^cfg_a4_wid)+1)*2^cfg_a4_wid;
else
	a4 = a4;
end


%----------- �������� ---------------------------
itr = 14;
c = 0;
for cnt = 0:itr-1
	%----------------
	tmp = floor(2^(-cnt) * 2^(itr-1));			%0+1+(itr-1)
	
	cfg_tmp_wid = 14;
	if tmp >= 2^cfg_tmp_wid
		tmp = mod(tmp,2^cfg_tmp_wid);
	elseif tmp >= 0
		tmp = tmp;
	else
		fprintf('tmp < 0: %d\n',tmp);
	end
	
	%----------------
	b3  = floor(2^(-cnt) * b2 * 2^-2 * 2^a4_point);	%0+3+a4_point
	
	cfg_b3_wid = 16;
	if b3 >= 2^cfg_b3_wid
		b3 = mod(b3,2^cfg_b3_wid);
	elseif b3 >= 0
		b3 = b3;
	else
		fprintf('b3 < 0: %d\n',b3);
	end
	
	%----------------
	if (a4 >= 0)
		a4 = a4 - b3;
		c  = c  + tmp;	%0+?+(itr-1)
	else
		a4 = a4 + b3;
		c  = c  - tmp;
	end
	
	%----------------
	cfg_a4_wid = 18;
	if (a4 >= 2^(cfg_a4_wid-1)) || (a4 < -2^(cfg_a4_wid-1))
		a4 = a4-(floor((a4-2^(cfg_a4_wid-1))/2^cfg_a4_wid)+1)*2^cfg_a4_wid;
	else
		a4 = a4;
	end
	
	cfg_c_wid = 14;
	if c >= 2^cfg_c_wid
		c = mod(c,2^cfg_c_wid);
	elseif c >= 0
		c = c;
	else
		fprintf('c < 0: %d\n',c);
	end
end

%-------- ����������λ ----------
%c2: 14=0+7+7
c2 = floor(c * 2^a_shift_bit * 2^-(itr-1) * 2^7);

cfg_c2_wid = 14;
if c2 >= 2^cfg_c2_wid
	c2 = mod(c2,2^cfg_c2_wid);
elseif c2 >= 0
	c2 = c2;
else
	fprintf('c2 < 0: %d\n',c2);
end

%------ ��ĸ�������������ͬʱҲ��ȫ���ţ��Լ�������� ----------
if b == 0 %��ĸΪ0
	if a > 0
		c3 = 2^15-1;
	elseif a < 0
		c3 = -2^15;
	else % a=0�����������
		c3 = 0;
	end
elseif b == -2^5
	c3 = -floor(a * 2^-3 * 2^-4 * 2^7);
elseif (a == -512) && (b == -1)
	c3 = 16384;
elseif (a == -512) && (b == 1)
	c3 = -16384;
else %��ĸ��Ϊ0
	if sign_flag == 0 %�Ǹ���
		c3 = c2;
	else %����
		c3 = -c2;
	end
end






